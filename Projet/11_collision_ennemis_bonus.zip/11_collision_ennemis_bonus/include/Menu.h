#ifndef MENU
#define MENU

void displayMenu();
void display(GLuint textureID);
GLuint loadTexture(const char* filename);

#endif
